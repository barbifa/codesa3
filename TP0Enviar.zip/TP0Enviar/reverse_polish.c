#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#include "reverse_polish.h"

void TratarValorNumerico(int num, TipoPilha *Pilha){
Empilha(num,Pilha);

}

void TratarOperador(char operador, TipoPilha *Pilha){
int num1,num2;
int total;

//printf("Operador lido : %c ",operador);

if(operador == '+'){
Desempilha(Pilha,&num1);
Desempilha(Pilha,&num2);
total = num1+num2;
Empilha(total,Pilha);


}else if (operador == '*'){

Desempilha(Pilha,&num1);
Desempilha(Pilha,&num2);
total = num1*num2;
Empilha(total,Pilha);


}

}



void somaUmBinario(int *binario, int contaOperador){

int k;

    for ( k = contaOperador-1 ; k>=0  ; k -- ){
     //printf("binario [%d] : %d ",k,binario[k]);
        if(binario[k]== 0 ){
            binario[k] = 1;
            break;
        } else if(binario[k] == 1){
        binario[k] = 0;

        }


    }// esse for apenas soma 1, uma vez
}

