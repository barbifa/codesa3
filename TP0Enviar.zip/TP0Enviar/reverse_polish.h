#ifndef REVERSE_POLISH_H_INCLUDED
#define REVERSE_POLISH_H_INCLUDED


void TratarValorNumerico(int num, TipoPilha *Pilha);
void TratarOperador(char operador, TipoPilha *Pilha);
void somaUmBinario(int *binario, int contaOperador);

#endif // REVERSE_POLISH_H_INCLUDED
