#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#include "reverse_polish.h"
#include <string.h>
#include <ctype.h>
#include <math.h>

int main()
{


int total;
char linha[255],linha2[255];
fgets(linha,255,stdin);
scanf("%d",&total);
strcpy(linha2,linha);
int i =0;
int tam;
int flag = 0;
int result;
/// dividindo entre espacos para pegar os numeros
char *pch;
pch = strtok(linha," ");
TipoPilha Pilha;
FPVazia(&Pilha);
char *opera;
int j=0;
int contaOperador = 0;

/* While pra contar numero de operadores*/
        while(pch!=NULL){
            tam = strlen(pch);
            if(pch[tam]=='\0'){
                tam= tam-1;
            }
            if(tam==0){
                if(pch[tam]=='\n'){
                flag = 0;
            }
            else if (isdigit(pch[0])==0){
                flag= 1;
            }
            }

            if(tam>0){
                for(i=0;i<tam;i++){
                    if (isdigit(pch[i])==0){ // returns 0 if is false
                        flag = 1;
                        break;

                    }
                }
            }
            if(flag == 1){ // entao, se for realmente um digito ele conta operador.
                contaOperador++;

            }
            else{
            //printf("topo %d",GetTopo(Pilha));
            }
            //transforma em numero
            flag = 0;
            pch=strtok(NULL," ");

        }



/*Pegar a quantidade de operadores e gerar todas as combinacoes possiveis*/
int nCombinacoesPossiveis;
nCombinacoesPossiveis = pow(2,contaOperador);
int l;
int *binario;
binario = malloc(contaOperador*sizeof(int));

//gerar binario + =0 ; * = 1
for ( l = 0 ; l < contaOperador ; l ++) {// 0(n) atribuir0 aos binarios iniciais
    binario[l] = 0;
} // inicializar binario com 000 , ou seja +++



opera = malloc(nCombinacoesPossiveis*sizeof(char));
int v=0;
int u;

for (u=0;u < nCombinacoesPossiveis; u++){ // para CADA combinacao faz isso O(2/\x) onde x eh o numero de operadores
        for( l = 0 ; l < contaOperador ; l++){ //o(x) ,x eh o numero de operadores
        // printf("[%d ] %d ",l,binario[l]);
        if(binario[l]==0){
            opera[v] = '+';
            v++;
        }else if (binario[l]==1){
            opera[v]='*';
            v++;
        }

        }// O vetor OPERA possui a possibilidade de operadores
v =0;
strcpy(linha,linha2);
pch = strtok(linha," ");
flag =0;
i = 0;
j = 0;

/*While para inserir na pilha*/
/*Le todo a string do inicio de novo, mas dessa vez
onde for caractere eh inserido a opcao que foi calculada acima*/

        while(pch!=NULL){ //o (n), onde n eh o tamanho da string
        //printf("\naqui :%s",pch);
            tam = strlen(pch);
                if(pch[tam]=='\0'){
                    tam= tam-1;
                }
        // printf("tam %d",tam);
            if(tam==0){

                if (isdigit(pch[0])==0){
                    flag = 1;
                }
            }
            if(tam>0){
                for(i=0;i<tam;i++){
                        if (isdigit(pch[i])==0){
                        flag = 1;
                    break;

                    }
                }
            }
        if(flag == 1){
            TratarOperador(opera[j],&Pilha);
            j++;
        }
        else{
            result = atoi(pch);
            TratarValorNumerico(result,&Pilha);
        }

        flag = 0;
        pch=strtok(NULL," ");

        }


/*Imprimindo a combinacao que eh igual ao total esperado*/
        if(GetTopo(Pilha)==total){
        //printf("\nO binario : ");
            for( l = 0 ; l < contaOperador ; l++){ //o(y) y= numero de operadores
                printf("%c",opera[l]);
            }
        printf("\n");
        }

memset(opera,0,strlen(opera));
somaUmBinario(binario,contaOperador);


}

free(binario);
free(opera);
return 0;
}
