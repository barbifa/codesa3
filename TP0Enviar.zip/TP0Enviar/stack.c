#include <stdio.h>
#include <stdlib.h>
#include "stack.h"


void FPVazia(TipoPilha *Pilha){
    Pilha->Topo = (TipoApontador) malloc(sizeof(TipoCelula));
    Pilha->Fundo = Pilha->Topo;
    Pilha->Topo->Prox = NULL;
    Pilha->tamanho =0 ;
}

int Vazia(TipoPilha Pilha){
return (Pilha.Topo == Pilha.Fundo);
}

void Empilha(int num,TipoPilha *pilha){
    TipoApontador Aux;
    Aux = (TipoApontador) malloc(sizeof(TipoCelula));
    pilha->Topo->num = num;
    Aux->Prox = pilha->Topo;
    pilha->Topo = Aux;
    pilha->tamanho++;

}

void Desempilha(TipoPilha *Pilha, int *num){
    TipoApontador q;
    if(Vazia(*Pilha)){
        printf("Erro: Lista vazia");
        return;
    }

    q =Pilha->Topo;
    Pilha->Topo = q->Prox;
    *num = q->Prox->num;
    free(q);
    Pilha->tamanho--;

}

int Tamanho(TipoPilha Pilha){
return(Pilha.tamanho);
}

int GetTopo (TipoPilha Pilha){
    TipoApontador q;
     q =Pilha.Topo->Prox;
    return q->num;

}


