#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

typedef struct TipoCelula *TipoApontador;
typedef struct TipoCelula{
int num;
int flag; //serve pra saber se nesse local esta um operador(1) ou numero(0).
TipoApontador Prox;
}TipoCelula;

typedef struct{
TipoApontador Fundo, Topo;
int tamanho;
}TipoPilha;

void FPVazia(TipoPilha *Pilha);
int Vazia(TipoPilha Pilha);
void Empilha(int num,TipoPilha *pilha);
void Desempilha(TipoPilha *Pilha, int *num);
int Tamanho(TipoPilha Pilha);
int GetTopo (TipoPilha Pilha);


#endif // STACK_H_INCLUDED
