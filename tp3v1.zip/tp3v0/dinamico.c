#include <stdio.h>
#include <stdlib.h>
#include "problem.h"
#include <math.h>

long int binaryToDecimal(int binario[], int n){
    int i,j=0;
   long int soma = 0;
    for ( i = n-1 ;i>=0; i --){
        if(binario[i]==1){
            soma = soma + pow(2,j);
           // printf("binario[%d] = %d",i,binario[i]);
          //  printf("som %d bina %d %d pow %f ",soma,binario[i],i,pow(2,j));
        }
        j++;
    }

   // printf("Numero eh = %d",soma);
return soma;

}

void removeCruzamentos(int retirado,int binario[], int n,TipoItem pares[]){
    int i;
    TipoItem aux;
    aux = pares[retirado];
    binario[retirado] = 0;

    //retirar TODOS os pares que cruzam com o retirado
      for(i = 0 ; i < n ; i ++){
        if(binario[i]==1){
           if(verificaCruzamento(aux,pares[i])==1){
                binario[i] = 0;
           }
        }
    }


}

int estaOcupado(Memo m[], long int decimal, int c){
    return -1;
    int i=0;
    while(i<c){
        if(m[i].decimal == decimal){
            return m[i].solucao;
        }
        i++;
    }
    return -1;

}

void salvarMemo(Memo m[],long int decimal,int solucao, int *c){
    m[*c].decimal = decimal;
    m[*c].solucao = solucao;
    m[*c].indicador = 1;
   
    m[*c+1].indicador = -1;


}

int A(int binario[],int n,TipoItem pares[],int k, Memo memo[],int *c){
    int m=0;
    int i;
    int r;
    long int decimal;
    int result;


      int *binarioAux = (int*)malloc(n*sizeof(int));

    for(i = 0; i< n ; i ++){
      //  binarioAux[i] = binario[i];
      //printf("binarioaux = %d binario %d \n",binarioAux[i],binario[i]);
      binarioAux[i] = binario[i];
  //  printf("binarioaux = %d binario %d \n",binarioAux[i],binario[i]);

    }

      removeCruzamentos(k,binarioAux,n,pares);
      decimal = binaryToDecimal(binarioAux,n);
      result = estaOcupado(memo,decimal,*c);
      if(result!=-1){
        return result;
      }

    if(binaryToDecimal(binarioAux,n)==0){
            //printf("#########\n");
            free(binarioAux);
        return 0;
    }


    for(i = 0;i<n;i++){
        if(binarioAux[i]==0){
            continue;
        }else{

//             for(j=0;j<n;j++){
//                printf(" depois de remover : binario[%d]=  %d \n",j,binario[j]);
//            }
            //printf(" Chamada %d \n",i);
            //for(x = 0; x< n ; x ++){ printf("%d ", binario[x]); }
            //printf("  %d \nDEPOIS\n",i);
            //for(x = 0; x< n ; x ++){ printf("%d ", binarioAux[x]); }
            //printf("\n");
            r = 1 + A(binarioAux,n,pares,i,memo, c);

            if(r>m){
                m = r;
            }



        }

    }

    salvarMemo(memo,decimal,m,c);


    return m;
}




