#include <stdio.h>
#include <stdlib.h>
#include "problem.h"
#include <math.h>
int main()
{
    int n;
    char op;
    int bar, dono,intervalo;
    int combinacoes;
    scanf("%c",&op);
    scanf("%d",&n);
    int i;
    TipoLista lista;
    TipoItem par;
    FLVazia(&lista);
    int melhor = 1;
    int c = 0;
    //int nCombinacoes= pow(2,n);
    //int binario[n];
    //par par[8];

    switch(op){

    case 'g':

        for(i = 0; i < n; i++){
            scanf("%d %d",&bar,&dono);
            //binario[i] = 0;
            intervalo = abs(bar - dono);
            par.bar = bar;
            par.dono = dono;
            par.intervalo = intervalo;
            par.pos = i;
            // printf("\n %d %d %d\n",par.bar,par.dono,par.intervalo);
            InsereOrdenado(par,&lista);
        }
	guloso(&lista);
	printf("%d\n",lista.tam);
	
	break;

    case 'b':

	combinacoes = pow(2,n);
	TipoItem *par = (TipoItem*)malloc(n*sizeof(TipoItem));
	int *binario = (int*)malloc(n*sizeof(int));
	int maxBandeiras;
	for(i = 0; i<n; i++){
		scanf("%d %d",&par[i].bar,&par[i].dono);
		binario[i]=0;
	}

	for(i = 0; i < combinacoes; i++){
		geraCombinacoes(binario,n);
		maxBandeiras =configuracaoBinario(binario,n,par);
		if(maxBandeiras>melhor){
			melhor = maxBandeiras;
		}

	}

	printf("%d\n", melhor);
	free(par);
	free(binario);



    break;
    case 'd': ;
	
	Memo *memo = (Memo*)malloc(pow(2,n)*sizeof(Memo));
	memo[0].indicador = -1;
	TipoItem *pars = (TipoItem*)malloc(n*sizeof(TipoItem));
	int *binario2 = (int*)malloc(n*sizeof(int));
	for(i = 0; i<n; i++){
		scanf("%d %d",&pars[i].bar,&pars[i].dono);
		binario2[i]=1;
	}

	int m = 0;
	int temp;
	//removeCruzamentos(0,binario,3,par);
	for(i = 0; i <n ; i ++){
		//printf("Chamada %d\n",i);
		temp = A(binario2,n,pars,i,memo,&c)+1;
		if(temp > m) m = temp;
	}
	printf("%d\n", m);

	free(binario2);
	free(pars);
	free(memo);


    break;

    }


}
