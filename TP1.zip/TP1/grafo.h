#ifndef GRAFO_H_INCLUDED
#define GRAFO_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include "grafo.h"
#define MAXNUMVERTICES  1000
#define MAXNUMARESTAS  1000000
#define FALSE           0
#define TRUE            1
#define INFINITO        INT_MAX

typedef struct TipoGrafo{
    int matriz[MAXNUMVERTICES][MAXNUMVERTICES];
    int numVertices;
    int numArestas;

}TipoGrafo;

void FGVazio(TipoGrafo *Grafo);
void InsereAresta(int v1, int v2,int p, TipoGrafo *Grafo);
int ExisteAresta(int v1, int v2,TipoGrafo *grafo);
void imprimeGrafo(TipoGrafo *grafo);
int buscaLargura(TipoGrafo *grafo,int s, int t,int parent[]);
void fordFulkerson(TipoGrafo *grafo, int s, int t,int *total);
void fluxoMaximo(TipoGrafo *grafo,int clientes[],int c,int franquias[],int f);
#endif // GRAFO_H_INCLUDED
