#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include "grafo.h"
#define MAXNUMVERTICES  1000
#define MAXNUMARESTAS  1000000
#define FALSE           0
#define TRUE            1
#define INFINITO        INT_MAX


void FGVazio(TipoGrafo *Grafo){
    int i,j;
    for(i = 1; i <= Grafo->numVertices ; i++){
        for(j = 1; j <= Grafo->numVertices;j++){
            Grafo->matriz[i][j] = 0;
        }
    }
}

void InsereAresta(int v1, int v2,int p, TipoGrafo *Grafo){
    Grafo->matriz[v1][v2] = p;
}

int ExisteAresta(int v1, int v2,TipoGrafo *grafo){
    return(grafo->matriz[v1][v2]>0);
}







void imprimeGrafo(TipoGrafo *grafo){
    int i,j;
    printf(" ");

    for(i = 1; i <= grafo->numVertices; i++){
        printf("%d ",i);
    }
    printf("\n");
    for(i = 1; i <= grafo->numVertices; i++){
        printf("%d ",i);
        for(j =1; j <=grafo->numVertices; j ++){
            printf("%d ",grafo->matriz[i][j]);
    }
    printf("\n");
}
}


int buscaLargura(TipoGrafo *grafo,int s, int t,int parent[]){
   int visitados[grafo->numVertices];
   int i;
   int *filaControle;
   int j=0;
   int tamFila=0;
   for(i = 0;i < grafo->numVertices; i++){
    visitados[i] = FALSE;
   }
 filaControle =(int*)malloc(grafo->numVertices*sizeof(int));
   filaControle[j] = s;
   tamFila = 1;
   visitados[s] =TRUE;
   parent[s]= -1;
   int v;
    int u;

   while(tamFila!=0){

     u = filaControle[j];
    j--;
    tamFila--;




    for(v = 0; v<grafo->numVertices;v++){
        if(visitados[v]==FALSE && grafo->matriz[u][v]>0){
            j++;
            tamFila++;
            filaControle[j] = v;
            parent[v] = u;
            visitados[v]= TRUE;
        }

    }



   }
   if(visitados[t]==TRUE){
   // printf("ENCONTRADO");
    return TRUE;
   }else{
   // printf("NAO ENCONTRADO");
    return FALSE;
   }




}

int min (int a, int b){
    if(a<b){
        return a;
    }  else{
        return b;
    }

}

void fordFulkerson(TipoGrafo *grafo, int s, int t,int *total){
    int u,v;
    int vertices = grafo->numVertices;

    //crianco um grafo Residual, que eh o que "sobrou " naquela aresta que poderia passar

    TipoGrafo grafoResidual;
    grafoResidual.numVertices = grafo->numVertices;
    grafoResidual.numArestas = grafo->numArestas;
    FGVazio(&grafoResidual);

    for (u = 0; u < vertices; u++){
        for ( v = 0; v < vertices ; v++){
            grafoResidual.matriz[u][v] = grafo->matriz[u][v];
        }
    }
   // imprimeGrafo(grafo);
   // imprimeGrafo(&grafoResidual);

    int parent[vertices];
    int max_flow =0;

    //vai aumentando o flow, enquanto tiver um caminho de s ate t

    while(buscaLargura(&grafoResidual,s,t,parent)){
        int path_flow = INFINITO;
        for(v = t; v!=s;v=parent[v]){
            u = parent[v];
            path_flow = min(path_flow,grafoResidual.matriz[u][v]);
        }

        for(v=t; v!=s; v=parent[v]){
            u = parent[v];
            grafoResidual.matriz[u][v] = grafoResidual.matriz[u][v] - path_flow;
            grafoResidual.matriz[v][u] = grafoResidual.matriz[u][v] + path_flow;


        }

        max_flow = max_flow+path_flow;



    }


   //  printf("\nMAX FLOW de franquia %d e cliente %d : %d\n",s,t,max_flow);



      for (u = 0; u < vertices; u++){
        for ( v = 0; v < vertices ; v++){
             grafo->matriz[u][v]=grafoResidual.matriz[u][v];
        }
    }

    *total = max_flow;


}

void fluxoMaximo(TipoGrafo *grafo,int clientes[],int c,int franquias[],int f){
// essa funcao vai imprimir o fluxo maximo de ci ate fi pra depois escolhermos o maior
int total;
int soma=0;
    int i;
    int j;
    for ( i = 0; i < f; i++){
        for( j = 0 ; j < c; j ++){
            fordFulkerson(grafo,franquias[i],clientes[j],&total);
             //printf("\n voltou :%d ",total);
             soma = total + soma;
        }
    }

    printf("%d\n",soma);



}
