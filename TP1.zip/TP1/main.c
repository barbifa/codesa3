#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include "grafo.h"
#define MAXNUMVERTICES  1000
#define MAXNUMARESTAS  1000000
#define FALSE           0
#define TRUE            1
#define INFINITO        INT_MAX


int main()
{
    int v,e,f,c;
    int i;
    TipoGrafo Grafo;
    int r1,r2,p;
    scanf("%d %d %d %d",&v,&e,&f,&c);
    Grafo.numArestas=e;
    Grafo.numVertices = v;
    FGVazio(&Grafo);
    int franquias[f];
    int clientes[c];

   for( i = 0 ; i < e; i ++){
     scanf("%d %d %d",&r1,&r2,&p);
     InsereAresta(r1,r2,p,&Grafo);

   }

   for(i = 0; i <f; i++){
    scanf("%d",&franquias[i]);
   }
   for(i = 0; i <c; i++){
    scanf("%d",&clientes[i]);
   }


 //  int parent[v];
  // buscaLargura(&Grafo,2,4,parent);

   // fordFulkerson(&Grafo,1,5);
    // fordFulkerson(&Grafo,1,7);

     // fordFulkerson(&Grafo,2,5);
    // fordFulkerson(&Grafo,2,7);

   fluxoMaximo(&Grafo,clientes,c,franquias,f);


    return 0;
}
