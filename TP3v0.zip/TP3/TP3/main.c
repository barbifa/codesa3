#include <stdio.h>
#include <stdlib.h>
#include "problem.h"
#include <math.h>
int main()
{
    int n;
    char op;
    int bar, dono,intervalo;
    int combinacoes;
    scanf("%c",&op);
    scanf("%d",&n);
    int i,j,k;
    TipoLista lista;
    TipoItem par;
    FLVazia(&lista);
    int melhor = 1;
    //int nCombinacoes= pow(2,n);
    //int binario[n];
    //par par[8];

    switch(op){

    case 'g':

        for(i = 0; i < n; i++){
            scanf("%d %d",&bar,&dono);
            //binario[i] = 0;
            intervalo = abs(bar - dono);
            par.bar = bar;
            par.dono = dono;
            par.intervalo = intervalo;
            par.pos = i;
            // printf("\n %d %d %d\n",par.bar,par.dono,par.intervalo);
            InsereOrdenado(par,&lista);
        }

  //  ImprimeLista(&lista);

    // guloso(&lista);
   // printf("\n After Guloso:\n");
    guloso(&lista);
    // Retira(lista.Primeiro->Prox,&lista);
    printf("%d\n",lista.tam);
    //(&lista);
    break;

    case 'b':
    combinacoes = pow(2,n);
    TipoItem *par = (TipoItem*)malloc(n*sizeof(TipoItem));
    int *binario = (int*)malloc(n*sizeof(int));

    int maxBandeiras;
    for(i = 0; i<n; i++){
        scanf("%d %d",&par[i].bar,&par[i].dono);
        binario[i]=0;
    }
    int j;
    for(i = 0; i < combinacoes; i++){
        //GeraBinario
        geraCombinacoes(binario,n);
        maxBandeiras =configuracaoBinario(binario,n,par);
    if(maxBandeiras>melhor){
        melhor = maxBandeiras;
    }

    //        for(j = 0; j < n ; j ++){
    //            printf("%d ",binario[j]);
    //        }
    //
    //        printf("\n");
    }

    printf("%d\n", melhor);



    break;
    case 'd':


    break;

    }


}
