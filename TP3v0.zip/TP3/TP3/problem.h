#ifndef PROBLEM_H_INCLUDED
#define PROBLEM_H_INCLUDED


typedef struct {
    int bar;
    int dono;
    int intervalo;
    int pos;
/* outros componentes */
} TipoItem;

typedef struct TipoCelula *TipoApontador;


typedef struct TipoCelula {
    TipoItem Item;
    TipoApontador Prox;
} TipoCelula;

typedef struct {
    TipoApontador Primeiro, Ultimo;
    int tam;
} TipoLista;

int verificaCruzamento(TipoItem a, TipoItem b); //forca bruta, dinamico e guloso
///---- FUNCOES DO GULOSO ----- ///
void FLVazia(TipoLista *Lista);

void ImprimeLista(TipoLista *l);

void InsereUltimo(TipoItem i, TipoLista l);

void InsereOrdenado(TipoItem i, TipoLista *l);

int Vazia(TipoLista Lista);

void Retira(TipoApontador p, TipoLista *Lista);



int cruza(TipoApontador anterior, TipoLista *l);

void guloso(TipoLista *l);

///---- FUNCOES DO FORCA BRUTA----- ///

void geraCombinacoes(int binario[],int n);

int cruzaBruto( TipoItem par[],int j);

int configuracaoBinario(int binario[], int n, TipoItem par[]);

int verificaCruzamentoBruto(TipoItem a, TipoItem b);





#endif // PROBLEM_H_INCLUDED
